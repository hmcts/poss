insert into dbauser.schemascripts
values
((select user from dual),
  sysdate,
  'Caseman-701c-0120',
  'Caseman-701c-0120');