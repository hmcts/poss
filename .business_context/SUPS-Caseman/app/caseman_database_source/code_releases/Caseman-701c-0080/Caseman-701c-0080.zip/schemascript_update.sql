insert into dbauser.schemascripts
values
((select user from dual),
  sysdate,
  'sups-caseman-701c-0080',
  'sups-caseman-701c-0080');