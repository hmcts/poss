insert into dbauser.schemascripts
values
((select user from dual),
  sysdate,
  'Caseman-701c-0132',
  'Caseman-701c-0132');