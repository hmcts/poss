insert into dbauser.schemascripts
values
((select user from dual),
  sysdate,
  'Caseman-701b-0461',
  'Caseman-701b-0461');