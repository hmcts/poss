insert into dbauser.schemascripts
values
((select user from dual),
  sysdate,
  'caseman-701b-0332',
  'caseman-701b-0332');