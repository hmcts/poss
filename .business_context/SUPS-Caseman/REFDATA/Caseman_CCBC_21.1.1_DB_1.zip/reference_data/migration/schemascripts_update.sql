insert into dbauser.schemascripts
values
((select user from dual),
  sysdate,
  'REFDATA refresh',
  'BUILD 7.200workshop1') ;

commit;