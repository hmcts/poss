-- Project:     SUPS Caseman
-- File:        init_legacy_seqs.sql
-- Author:      Chris Hutt
-- Created:     6 feb 2006 
-- Description: Set up SYSTEM_DATA ITEM rows for seq identified as being used in legacy but NOT in SUPS caseman
--
-- Change History:
-- 22/06/06 Chris Hutt - limited to courts where SUPS_CENTRALISED_FLAG = 'Y'


DECLARE
	ct_code		courts.code%type;
	item_val	system_data.item_value%type;
		
	CURSOR c_courts(p_item_name SYSTEM_DATA.ITEM%type) IS
	SELECT	CT.CODE
	FROM	COURTS CT
	WHERE	CT.SUPS_CENTRALISED_FLAG = 'Y'
	AND     CT.CODE NOT IN (
			SELECT	SD.ADMIN_COURT_CODE
			FROM	SYSTEM_DATA SD
			WHERE	ITEM = p_item_name
		);

	
PROCEDURE createSequences(p_item_name IN SYSTEM_DATA.ITEM%type, p_item_value IN SYSTEM_DATA.ITEM_VALUE%type) AS
BEGIN
	OPEN c_courts(p_item_name);
	LOOP
	FETCH c_courts INTO ct_code;
		IF c_courts%NOTFOUND THEN
			CLOSE c_courts;
			EXIT;
		ELSE
			INSERT INTO	SYSTEM_DATA
					(ITEM, ITEM_VALUE, ITEM_VALUE_CURRENCY, ADMIN_COURT_CODE)
			VALUES		(p_item_name, p_item_value, NULL, ct_code);
		END IF;
	END LOOP;
END createSequences;

BEGIN

	createSequences('AE', 0);
	createSequences('CRD1', 0);
	createSequences('CRD2', 0);
	createSequences('DIV', 0);
	createSequences('FOREIGN', 0);
	createSequences('HOME', 0);
	createSequences('IN SATISFACTION', 0);
	createSequences('JUDG', 0);
	createSequences('ORD1', 0);
	createSequences('ORD2', 0);
	createSequences('PAY', 0);
	createSequences('PCO', 0);
	createSequences('PROG', 0);
	createSequences('REISSUE', 0);
	createSequences('TCO', 0);
	
	
	COMMIT;
END;
/