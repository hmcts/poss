-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsPERF.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the Performance environment
--		
-- NOTE: extra system_data items
--
-- Change History:
-- 

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

@system_data_perf_extras.sql

