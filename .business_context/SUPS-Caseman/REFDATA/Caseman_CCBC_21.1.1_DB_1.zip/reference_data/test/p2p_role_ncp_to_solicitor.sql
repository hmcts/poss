-- File:   p2p_role_ncp_to_solicitor.sql
-- Date:   03-Aug-2006
-- Author: Phil Haferer
-- Description:
--     TD CASEMAN 4133: CCBC: Change Role Type from NCP to SOLICITOR.

call sys.set_sups_app_ctx ('casm_100', '100', 'Ncp2Sol');

UPDATE PARTY_TO_PARTY_RELATIONSHIP P2P
SET    P2P.PARTY_A_ROLE_CODE = 'SOLICITOR'
WHERE  P2P.PARTY_A_ROLE_CODE = 'NCP';

UPDATE PARTIES PP
SET    PP.PARTY_TYPE_CODE = 'SOLICITOR'
WHERE  PP.PARTY_TYPE_CODE = 'NCP';

COMMIT;
