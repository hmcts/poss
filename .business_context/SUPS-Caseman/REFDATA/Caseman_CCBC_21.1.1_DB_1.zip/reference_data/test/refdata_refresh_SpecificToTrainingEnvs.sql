-- Project:     SUPS Caseman
-- File:        refdata_refresh_SpecificToTrainingEnvs.sql
-- Author:      Chris Hutt
-- Created:     20 feb 2008 
-- Description: Run scripts loading reference data which is classified as being specific to
--              training environments (NON LIVE!)
--              
--
-- Change History:
                     


set define off

exec set_sups_app_ctx('a','b','c');


@courts.sql
@training_courts.sql
@given_addresses.sql
@training_given_addresses.sql
@personalise.sql
@training_personalise.sql
@init_personalise.sql

-- THIS BLOCK RELATES TO THE SYSTEM_DATA
@init_system_data_seqs.sql
@init_system_data_non_seqs.sql
@init_ae_seq.sql
@init_co_seq.sql
@init_warrants_seq.sql
@create_cfo_item.sql

@init_printer_court_code.sql











