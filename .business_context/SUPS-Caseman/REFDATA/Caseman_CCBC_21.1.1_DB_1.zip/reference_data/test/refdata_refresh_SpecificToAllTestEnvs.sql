-- Project:     SUPS Caseman
-- File:        refdata_refresh_SpecificToAllTestEnvs.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              test environments.
--              A 'test environment' to taken to be:
--              1) development / integration
--              2) IntegrationTest (IT)
--              3) FunctionTest (FT)
--              4) Performance
--              5) UserConfidence (UCT)
--              6) UserAcceptance (UAT)
--              
--
-- Change History:
--	Chris Hutt 30 Nov 2006 - init_sections.sql removed
--    	Chris Hutt 17 may 2007 - as part of move from test set of courts to live versions it is
--				 necessary to null out existing COURTS.ID to ensure that no duplicates
--                               exist in the live/test sets.
--
--      Chris Hutt 11 Feb 2008 - ICR0470 DCA_USER.PRINTER_COURT_CODE added. Populated with USER_COURT.COURT_CODE
--                               as default value.                          


set define off

exec set_sups_app_ctx('a','b','c');

update courts set id = null;

@courts.sql
@create_court_sections.sql
@given_addresses.sql
@parties.sql
@sections.sql
@dca_user.sql
@user_role.sql
@user_court.sql
@init_personalise.sql
@personalise.sql

@init_printer_court_code.sql










