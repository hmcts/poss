-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsIT01.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the IT01 environment
--		
-- NOTE: printer allocation currently hed in dca_user.csv and court.csv
--
-- Change History:
-- Chris Hutt 17 may 2007. Printer allocation for COURTS
-- Chris Hutt 13 feb 2008. Printer allocation for users.

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

update courts 
set default_printer = 'CSP00001', fap_id = 'csf20069';

update dca_user d
set d.user_default_printer = 'CSP00001';

commit;