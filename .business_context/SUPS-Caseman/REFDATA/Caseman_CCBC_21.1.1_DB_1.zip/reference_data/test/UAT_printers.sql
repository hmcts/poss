
-- UAT_printers.sql
-- 1. Sets up printer allocation
-- Based on SQL supplied by Amit Narang, Sarndip Sandhu
--
-- Chris Hutt 2 nov 2006
--
-- Change history
-- 


-- PRINTER ALLOCATIONS
UPDATE COURTS SET FAP_ID = 'CSF20099' , DEFAULT_PRINTER = 'Xerox_Caseman' ;

UPDATE DCA_USER SET USER_DEFAULT_PRINTER = 'Xerox_Caseman';

COMMIT;