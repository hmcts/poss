-- Project:     SUPS Caseman
-- File:        refdata_initialisation_SpecificToTraining.sql
-- Author:      Chris Hutt
-- Created:     20Feb2008 
-- Description: TO BE RUN ONLY IN TRAINING ENVIRONMENTS
-- 
-- DO NOT RUN THIS SCRIPT!! IT WILL BE CALLED BY ENVIRONMENT SPECIFIC SCRIPTS
--
-- Change History:
-- 


set define off

exec set_sups_app_ctx('a','b','c');

-- THIS BLOCK RELATES TO THE SYSTEM_DATA
@init_system_data_seqs.sql
@init_system_data_non_seqs.sql
@init_ae_seq.sql
@init_co_seq.sql
@init_warrants_seq.sql
@create_cfo_item.sql

@init_printer_court_code.sql



