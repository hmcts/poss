-- Project:     SUPS Caseman
-- File:        init_system_data_non_seqs.sql
-- Author:      Chris Hutt
-- Created:     6 feb 2006 
-- Description: Set up SYSTEM_DATA ITEM rows for non sequential items identified as being used in legacy but NOT in SUPS caseman
--
-- Change History:
-- ---------------
-- v1.1 CJH 03/03/2006 BMS_LIVE_DATE & CO_RUNDATE corrected
-- v1.2 CJH 08/03/2006 CFO RUNDATE, SUPS_LIVE_DATE, CP RUNDATE and AE_GOLIVE_DATE added
-- v1.3 CJH 22/05/2006 CO_RUNDATE and AE_RUNDATE replaced with 'CO RUNDATE' and 'AE RUNDATE'
-- v1.4 CJH 26/05/2006 SEVICE_PERIOD, CO_RESPONSE_PERIOD, RESPONSE_PERIOD - underscores removed (TD3462)
-- 22/06/06 Chris Hutt - limited to courts where SUPS_CENTRALISED_FLAG = 'Y'
-- 22/06/06 Chris Hutt - LIST REDRAFTED IN LINE WITH SYSTEM_DATA RATIONALISATION


DECLARE
	ct_code		courts.code%type;
	item_val	system_data.item_value%type;
		
	CURSOR c_courts(p_item_name SYSTEM_DATA.ITEM%type) IS
	SELECT	CT.CODE
	FROM	COURTS CT
	WHERE	CT.SUPS_CENTRALISED_FLAG = 'Y'
	AND     CT.CODE != '0'
	AND     CT.CODE NOT IN (
			SELECT	SD.ADMIN_COURT_CODE
			FROM	SYSTEM_DATA SD
			WHERE	ITEM = p_item_name
		);

	
PROCEDURE createCurrencyItems(	p_item_name IN SYSTEM_DATA.ITEM%type, p_item_value IN SYSTEM_DATA.ITEM_VALUE%type) AS
BEGIN
	OPEN c_courts(p_item_name);
	LOOP
	FETCH c_courts INTO ct_code;
		IF c_courts%NOTFOUND THEN
			CLOSE c_courts;
			EXIT;
		ELSE
			INSERT INTO	SYSTEM_DATA
					(ITEM, ITEM_VALUE, ITEM_VALUE_CURRENCY, ADMIN_COURT_CODE)
			VALUES		(p_item_name, p_item_value, 'GBP', ct_code);
		END IF;
	END LOOP;
END createCurrencyItems;

PROCEDURE createNonCurrencyItems(	p_item_name IN SYSTEM_DATA.ITEM%type, p_item_value IN SYSTEM_DATA.ITEM_VALUE%type) AS
BEGIN
	OPEN c_courts(p_item_name);
	LOOP
	FETCH c_courts INTO ct_code;
		IF c_courts%NOTFOUND THEN
			CLOSE c_courts;
			EXIT;
		ELSE
			INSERT INTO	SYSTEM_DATA
					(ITEM, ITEM_VALUE, ITEM_VALUE_CURRENCY, ADMIN_COURT_CODE)
			VALUES		(p_item_name, p_item_value, NULL, ct_code);
		END IF;
	END LOOP;
END createNonCurrencyItems;

PROCEDURE clearUp( p_item_name IN SYSTEM_DATA.ITEM%type ) AS
BEGIN
    DELETE FROM SYSTEM_DATA
    WHERE ITEM = p_item_name;
END clearUp;

BEGIN

	createNonCurrencyItems('AE RUNDATE', '20050728');
	createNonCurrencyItems('AE_GOLIVE_DATE', '20050728');
	createNonCurrencyItems('BMS_LIVE_DATE', '20050728');
	createNonCurrencyItems('SUPS_LIVE_DATE', '20050728');
	createNonCurrencyItems('CFO RUNDATE', '20050728');
	createNonCurrencyItems('CM_CD_R4', '1');
	createNonCurrencyItems('CO RUNDATE', '20050728');
	createNonCurrencyItems('CO_R8_LAST_EVENT', '1140556');
	createNonCurrencyItems('CP RUNDATE', '20050728');
	createNonCurrencyItems('FAMILYMAN1', '0');
	createNonCurrencyItems('FM_COURT', '0');
	createNonCurrencyItems('NCP_LIVE_DATE', '19980522');
	createNonCurrencyItems('PUBLISH_TASKS_FLAG', '0');
	createNonCurrencyItems('AE_GOLIVE_DATE', '19980522');
	createCurrencyItems('CASE_COST_BASIC', '7350');
	createNonCurrencyItems('CO RESPONSE PERIOD', '16');


	-- createCurrencyItems('FEE_BAND_1', '150000');
	-- createCurrencyItems('FEE_BAND_2', '200000');
	-- createCurrencyItems('FEE_BAND_3', '250000');
	-- createCurrencyItems('FEE_BAND_4', '300000');
	-- createCurrencyItems('FEE_LIMIT_1', '1100');
	-- createCurrencyItems('FEE_LIMIT_2', '1300');
	-- createCurrencyItems('FEE_LIMIT_3', '1500');
	-- createCurrencyItems('FEE_LIMIT_4', '1700');


	
	clearUp('CO_RUNDATE');
	clearUp('AE_RUNDATE');
	clearUp('CO_RESPONSE_PERIOD');
	clearUp('RESPONSE_PERIOD');
	clearUp('SERVICE_PERIOD');
	
	
	COMMIT;
END;
/