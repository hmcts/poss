-- Project:     SUPS Caseman
-- File:        refdata_CCBC_master.sql
-- Author:      Chris Hutt
-- Created:     20FEB08
-- Description: A fix ref data refresh for the CMANTAA01 environment
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_refresh_SpecificToTrainingEnvs.sql

-- Printer allocations for the courts
--1) defaults
update courts c
set  c.deed_pack_number = '000000' ;

--2) specifics
update courts c
set   c.default_printer  = 'CSP01524'
    , c.deed_pack_number = '000232'
    , c.fap_id           = 'CSF20125' 
where c.code = 180;

update courts c
set   c.default_printer  = 'CSP01177'
    , c.deed_pack_number = '000755'
    , c.fap_id           = 'CSF10134' 
where c.code = 189;

update courts c
set   c.default_printer  = 'CSP01323'
    , c.deed_pack_number = '000676'
    , c.fap_id           = 'CSF20139' 
where c.code = 282;

update courts c
set   c.default_printer  = 'CSP00124'
    , c.deed_pack_number = '000160'
    , c.fap_id           = 'CSF20102' 
where c.code = 287;

update courts c
set   c.default_printer  = 'CSP01845'
    , c.deed_pack_number = '000660'
    , c.fap_id           = 'CSF20158' 
where c.code = 358;

update courts c
set   c.default_printer  = 'csp00002'
    , c.deed_pack_number = '000378'
    , c.fap_id           = 'csf20070' 
where c.code = 378;

update courts c
set   c.default_printer  = 'csp00001'
    , c.deed_pack_number = 'z00061'
    , c.fap_id           = 'csf20069' 
where c.code = 439;

update courts c
set   c.default_printer  = 'csp00001'
    , c.deed_pack_number = '000002'
    , c.fap_id           = 'csf20069' 
where c.code = 910;

update courts c
set   c.default_printer  = 'csp00001'
    , c.deed_pack_number = '000713'
    , c.fap_id           = 'csf20069' 
where c.code = 911;

update courts c
set   c.default_printer  = 'csp00001'
    , c.deed_pack_number = 'z00062'
    , c.fap_id           = 'csf20069' 
where c.code = 920;


commit;