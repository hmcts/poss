-- NOTE: This script only really needs executed once in response to TD CASEMAN 3959.
DECLARE
    /*
        File:   co_event_200_hrg_seq.sql
        Date:   31-Jul-2006
        Author: Phil Haferer
        Description:
            The HRG_SEQ column of CO_EVENTS has not been updated due to the column missing from update map.
            This script attempts to assign a value to this column, so that updates to Hearings can also update 
            the related CO_EVENTS row.
            TD CASEMAN 3959: MAINTAIN CO HEARING - UC008: The CO Hearing Event 200 is not updated in line 
                             with a revised hearing date/time.
    */
    
	/* Consolidated Orders that don't have HRG_SEQ set. */
	CURSOR c_co_with_null_hrg_seq IS 
		SELECT  CO.CO_NUMBER
		,       CO.ADMIN_COURT_CODE
		FROM    CONSOLIDATED_ORDERS CO
		WHERE   CO.CO_NUMBER IN 
		(SELECT  DISTINCT COE.CO_NUMBER
		 FROM    CO_EVENTS COE
		 WHERE   COE.STD_EVENT_ID = 200 
		 AND     COE.HRG_SEQ IS NULL);
		
    /* List of the primary keys of Hearings for a Consolidated Order. */
	CURSOR c_co_hearing_seqs(p_co_number hearings.co_number%TYPE) IS 
		SELECT  H.HRG_SEQ
		FROM    HEARINGS H
		WHERE   H.CO_NUMBER = p_co_number
		AND     H.HRG_SEQ IN
		(SELECT H1.HRG_SEQ
		 FROM   CO_EVENTS COE
		 ,      HEARINGS  H1
		 WHERE  COE.CO_NUMBER    = H.CO_NUMBER
		 AND    COE.STD_EVENT_ID = 200
		 AND    H1.CO_NUMBER     = COE.CO_NUMBER
		 AND    COE.HRG_SEQ      IS NULL)
		ORDER BY H.HRG_SEQ ASC;

	/* List of primary keys of CO Events for Hearings for a Consolidated Order. */
	CURSOR c_co_event_seqs_for_hearings(p_co_number co_events.co_number%TYPE) IS 
		SELECT  COE.CO_EVENT_SEQ
		FROM    CO_EVENTS COE
		WHERE   COE.CO_NUMBER = p_co_number
		AND     COE.STD_EVENT_ID = 200
		AND     COE.HRG_SEQ      IS NULL
		ORDER BY COE.CO_EVENT_SEQ ASC;
		    		
    l_co_number        consolidated_orders.co_number%TYPE;
    l_admin_court_code consolidated_orders.admin_court_code%TYPE;
    l_co_event_seq     co_events.co_event_seq%TYPE;
    l_hrg_seq          hearings.hrg_seq%TYPE;

BEGIN
	OPEN c_co_with_null_hrg_seq;
	LOOP
    	FETCH c_co_with_null_hrg_seq INTO l_co_number, l_admin_court_code;
		IF c_co_with_null_hrg_seq%NOTFOUND THEN
			CLOSE c_co_with_null_hrg_seq;
			EXIT;
		ELSE
            sys.set_sups_app_ctx(
                'casm_'||TO_CHAR(l_admin_court_code),
                l_admin_court_code,
                'HrgSeq');

        	OPEN c_co_hearing_seqs(l_co_number);
        	OPEN c_co_event_seqs_for_hearings(l_co_number);        	
        	LOOP
            	FETCH c_co_event_seqs_for_hearings INTO l_co_event_seq;
            	FETCH c_co_hearing_seqs INTO l_hrg_seq;
        		IF c_co_event_seqs_for_hearings%NOTFOUND OR 
        		   c_co_hearing_seqs%NOTFOUND 
        		THEN
        			CLOSE c_co_hearing_seqs;
        			CLOSE c_co_event_seqs_for_hearings;
        			EXIT;
        		ELSE
                    UPDATE CO_EVENTS COE
                    SET    COE.HRG_SEQ      = l_hrg_seq
                    WHERE  COE.CO_EVENT_SEQ = l_co_event_seq
                    AND    COE.HRG_SEQ      IS NULL;
        		END IF;
            END LOOP;
		
		    COMMIT;
		END IF;
    END LOOP;
END;
/
