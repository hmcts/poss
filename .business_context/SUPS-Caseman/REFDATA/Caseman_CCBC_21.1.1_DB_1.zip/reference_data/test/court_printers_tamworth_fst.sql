update courts set fap_id = 'csf20099', default_printer = 'xeroxtt0';
commit;