-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsUAT.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the UAT environment
--		
-- NOTE: printer allocation needs attention
--
-- Change History:
-- 

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

-- printer allocation
@tamworth_courts.sql
@court_fapids_tamworth_uct.sql
@UAT_printers.sql
@UAT_courts.sql
@UAT_SUPS_courts.sql

