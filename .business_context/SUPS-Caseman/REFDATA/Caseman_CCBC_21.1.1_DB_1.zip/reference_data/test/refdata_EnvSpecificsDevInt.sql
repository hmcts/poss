-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsDevInt.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the DevInt environment
--		
-- NOTE: printer allocation currently hed in dca_user.csv and court.csv
--
-- Change History:
-- 

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

