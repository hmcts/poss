-- WARNING! NOT TO BE EXECUTED ON MIGRATED DATABASES.
--          This script is intended to help configure Development/Function Test Database only.
--          Migrated Databases should already have the appropriate existing SYSTEM_DATA rows.
--
-- Project:     SUPS Caseman
-- File:        init_ae_seq.sql
-- Author:      Phil Haferer (EDS)
-- Created:     14-Mar-2006 
-- Description: Attach of Earnings Applications are identified by a unique value, referred to as the 'AE Number'.
--              AE Numbers are of the format: XXXYNNNN
--              Where XXX  = Court Code (eg 111).
--                    Y    = Enforcement Letter
--                    NNNN = Next sequence for the current Court.
--              The four digit sequence number is derived from a row in the table SYSTEM_DATA.
--              There is one row per Court, identified by the column ITEM = 'AE'.
--              This PL/SQL will created one SYSTEM_DATA row for each court that does not already have one.
--              It will attempt to inspect existing AE_APPLICATIONS rows in order to determine what the 
--              current sequence number should be set to.
--
-- Change History:
-- 06-Apr-2006 Phil Haferer: Change the way the max value is selected from the AE_APPLICATIONS table,
--             as the Court Code at the beginning of the AE Number did not always match the Issuing court.
--
-- 22/06/06 Chris Hutt - limited to courts where SUPS_CENTRALISED_FLAG = 'Y'
declare

    procedure create_system_data_sequence(
        p_item_name in SYSTEM_DATA.ITEM%type, 
        p_item_value in SYSTEM_DATA.ITEM_VALUE%type) as

    	cursor c_courts(
    	    p_item_name SYSTEM_DATA.ITEM%type)
    	is
        	SELECT	CT.CODE
        	FROM	COURTS CT
        	WHERE	CT.SUPS_CENTRALISED_FLAG = 'Y'
        	AND     CT.CODE not in 
        	(SELECT	SD.ADMIN_COURT_CODE
    		 FROM	SYSTEM_DATA SD
    		 WHERE	SD.ITEM = p_item_name
            );
      
      court_code courts.code%type;
      
    begin
        open c_courts(p_item_name);
        loop
            fetch c_courts into court_code;
        	if c_courts%notfound then
        		close c_courts;
        		exit;
        	else
        		INSERT INTO	SYSTEM_DATA
        		( ITEM
        		, ITEM_VALUE
        		, ITEM_VALUE_CURRENCY
        		, ADMIN_COURT_CODE
        		) VALUES 
        		( p_item_name
        		, p_item_value
        		, NULL
        		, court_code
        		);
        	end if;
        end loop;        
    end create_system_data_sequence;
    
    procedure set_ae_nextval as

        -- Get the Maximum AE_NUMBER for each Court.
        -- Ignore rows that contain badly formatted Warrant Numbers.
        cursor c_get_nextval is
            SELECT COURT_CODE
            ,      MAX(SEQVAL)
            FROM (
            SELECT AE.AE_NUMBER
            ,      SUBSTR(AE.AE_NUMBER, 1, 3) "COURT_CODE"
            ,      SUBSTR(AE.AE_NUMBER, 5, 8) "SEQVAL"
            FROM   AE_APPLICATIONS AE
            WHERE  LENGTH(AE.AE_NUMBER) = 8
            AND    SUBSTR(AE.AE_NUMBER, 3, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(AE.AE_NUMBER, 4, 1) NOT IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(AE.AE_NUMBER, 5, 1) IN ('0','1','2','3','4','5','6','7','8','9')  
            )
            GROUP BY COURT_CODE;

    	court_code     AE_APPLICATIONS.ISSUING_CRT_CODE%type;
    	max_ae_number        AE_APPLICATIONS.AE_NUMBER%type;
    	sequence_number      SYSTEM_DATA.ITEM_VALUE%type;

    begin
        open c_get_nextval;
        loop
            fetch c_get_nextval into 
                court_code,
                max_ae_number;
        	if c_get_nextval%notfound then
        		close c_get_nextval;
        		exit;
        	else
				-- Convert to a number.
				sequence_number := TO_NUMBER(max_ae_number);

				-- Set to the next available number.
				sequence_number := sequence_number + 1;
        		
        		UPDATE SYSTEM_DATA  SD
        		SET    ITEM_VALUE   = sequence_number
        		WHERE  SD.ITEM      = 'AE'
        		AND    SD.ADMIN_COURT_CODE = court_code;
        	end if;
        end loop;        
    end set_ae_nextval;
    
begin
    create_system_data_sequence('AE', 1);
    set_ae_nextval;
    commit;
end;
/

