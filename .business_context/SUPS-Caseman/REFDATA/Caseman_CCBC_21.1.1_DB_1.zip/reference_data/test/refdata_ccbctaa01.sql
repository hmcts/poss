-- Project:     SUPS Caseman
-- File:        refdata_CCBC_master.sql
-- Author:      Chris Hutt
-- Created:     31may07 
-- Description: A fix ref data refresh for the CCBCTAA01 environment
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_refresh_SpecificToTrainingEnvs.sql

-- Printer allocations for the courts
update courts c
set   c.default_printer  = 'csp00001'
    , c.deed_pack_number = '000'||c.code 
    , c.fap_id           = 'csf20069' ;


commit;