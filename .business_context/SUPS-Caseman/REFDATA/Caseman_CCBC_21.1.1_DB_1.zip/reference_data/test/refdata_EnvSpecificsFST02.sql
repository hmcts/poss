-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsFST02.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the FST02 environment
--		
-- NOTE: printer allocation currently done in tamworth_courts_fst.sql
--
-- Change History:
-- 

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

@tamworth_courts_fst.sql

update courts set sups_centralised_flag = 'N'
where code in (998);

