-- Script to remove BMS tasks added to reference data
-- as a result of inaccurate information supplied as part of
-- the CCBC BMS requirement. All the codes being removed should 
-- have been padded out with zeroes (eg BC009 instead of BC9)
--
-- The update will fail due to referential integrity issues 
-- should the incorrect codes be used on CASE_EVENTS. The solution
-- in this situation will be to updatye CASE_EVENTS.BMS_TASK_NUMBER
-- to the correct code before proceeding with this delete.
--
-- Chris Hutt 20 July 2007
-- Defect UCT GRoup2 : 1525

delete from tasks t
where t.task_number in ('BC8', 'BC9', 'BC19' , 'BC28' , 'BC32');

commit;