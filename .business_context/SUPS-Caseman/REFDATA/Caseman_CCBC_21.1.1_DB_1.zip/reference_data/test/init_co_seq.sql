-- WARNING! NOT TO BE EXECUTED ON MIGRATED DATABASES.
--          This script is intended to help configure Development/Function Test Database only.
--          Migrated Databases should already have the appropriate existing SYSTEM_DATA rows.
--
-- Project:     SUPS Caseman
-- File:        init_co_seq.sql
-- Author:      Phil Haferer (EDS)
-- Created:     07-Nov-2005 
-- Description: Consolidated Orders are identified by a unique value, referred to the 'CO Number'.
--              This consists of the last two digits of the year, a four digit sequence number,
--              and a two character Court Id.
--              The four digit sequence number is derived from a row in the table SYSTEM_DATA.
--              There is one row per Court, identified by the column ITEM = 'CO'.
--              This PL/SQL will created one SYSTEM_DATA row for each court that does not already have one.
--              It will attempt to inspect existing CONSOLIDATED_ORDERS rows in order to determine what the 
--              current sequence number should be set to.
-- 12/06/2006 PEH: Refined the criteria for identifying the max CO Number.
--
-- 22/06/06 Chris Hutt - limited to courts where SUPS_CENTRALISED_FLAG = 'Y'

DECLARE
	ct_code    courts.code%type;
	ct_id      courts.id%type;
	item_value      SYSTEM_DATA.ITEM_VALUE%type;
	max_co_number   CONSOLIDATED_ORDERS.CO_NUMBER%type;
	txt_co_sequence CONSOLIDATED_ORDERS.CO_NUMBER%type;
	co_sequence     SYSTEM_DATA.ITEM_VALUE%type;

	CURSOR c_existing_sequences IS
		SELECT  SD.ADMIN_COURT_CODE
		,       SD.ITEM_VALUE
		,       CT.ID
		FROM    SYSTEM_DATA SD
		,       COURTS      CT
		WHERE   SD.ADMIN_COURT_CODE = CT.CODE
		AND     SD.ITEM = 'CO';		
		
	CURSOR c_missing_courts IS 
		SELECT  CT.CODE
		,       CT.ID
		FROM    COURTS CT
		WHERE   CT.SUPS_CENTRALISED_FLAG = 'Y'
		AND     NOT CT.CODE IN 
		(SELECT SD.ADMIN_COURT_CODE
		 FROM   SYSTEM_DATA SD
		 WHERE  SD.ITEM = 'CO');
	
	CURSOR c_max_co_number(
		p_admin_court_code CONSOLIDATED_ORDERS.ADMIN_COURT_CODE%type,
		p_court_id         COURTS.ID%type) IS 
		SELECT MAX(CO.CO_NUMBER)
		FROM   CONSOLIDATED_ORDERS CO
		WHERE  CO.ADMIN_COURT_CODE = p_admin_court_code
        AND    LENGTH(CO.CO_NUMBER) = 8
        AND    SUBSTR(CO.CO_NUMBER, 1, 1) IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 2, 1) IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 3, 1) IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 4, 1) IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 5, 1) IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 6, 1) IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 7, 1) NOT IN ('0','1','2','3','4','5','6','7','8','9')
        AND    SUBSTR(CO.CO_NUMBER, 8, 1) NOT IN ('0','1','2','3','4','5','6','7','8','9')
		AND    CO.CO_NUMBER LIKE CONCAT('%', p_court_id);
BEGIN
	OPEN c_existing_sequences;
	LOOP
    	FETCH c_existing_sequences INTO ct_code, item_value, ct_id;
		IF c_existing_sequences%NOTFOUND THEN
			CLOSE c_existing_sequences;
			EXIT;
		ELSE
			OPEN c_max_co_number(ct_code, ct_id);
	    	FETCH c_max_co_number INTO max_co_number;
			IF c_max_co_number%FOUND THEN
				txt_co_sequence := SUBSTR(max_co_number, 3, 4);
				co_sequence := TO_NUMBER(txt_co_sequence);
				co_sequence := co_sequence + 1;
				IF item_value < co_sequence THEN
					UPDATE SYSTEM_DATA SD
					SET    SD.ITEM_VALUE = co_sequence
					WHERE  SD.ADMIN_COURT_CODE = ct_code
					AND    SD.ITEM = 'CO';
				END IF;
			END IF;
			CLOSE c_max_co_number;
		END IF;
    END LOOP;	

	OPEN c_missing_courts;
	LOOP
    	FETCH c_missing_courts INTO ct_code, ct_id;
		IF c_missing_courts%NOTFOUND THEN
			CLOSE c_missing_courts;
			EXIT;
		ELSE
			-- Get the next value.
			OPEN c_max_co_number(ct_code, ct_id);
	    	FETCH c_max_co_number INTO max_co_number;
			IF c_max_co_number%NOTFOUND THEN
				item_value := 0;
			ELSE
				txt_co_sequence := SUBSTR(max_co_number, 3, 4);
				item_value := TO_NUMBER(txt_co_sequence);
				item_value := item_value + 1;
			END IF;
			CLOSE c_max_co_number;
			
			INSERT INTO SYSTEM_DATA 
			(      ITEM
			,      ITEM_VALUE
			,      ITEM_VALUE_CURRENCY
			,      ADMIN_COURT_CODE
			) VALUES 
			(      'CO'
			,      item_value
			,      NULL
			,      ct_code);
		END IF;
    END LOOP;	
END;
/
