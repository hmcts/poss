-- WARNING! NOT TO BE EXECUTED ON MIGRATED DATABASES.
--          This script is intended to help configure Development/Function Test Database only.
--          Migrated Databases should already have the appropriate existing SYSTEM_DATA rows.
--
-- Project:     SUPS Caseman
-- File:        init_warrants_seq.sql
-- Author:      Phil Haferer (EDS)
-- Created:     13-Mar-2006 
-- Description: Warrants are identified by three different unique values, within each Court.
--
--              Home Warrants :-
--                  This is 7 digit sequential number, padded with zeros, which is prefixed by a single character 
--              alphabetic 'Enforcement' character which represents the current year, for example T0000342.
--              These derive their next value from rows where SYSTEM_DATA.ITEM = "HOME", for the court WARRANTS.ISSUED_BY.
--              Stored in the column WARRANTS.WARRANT_NUMBER.
--
--              Foreign Warrants (Local Number) :-
--                  This is 5 digit sequential number, padded with zeros, which is prefixed by the characters "FW"
--              and a single character alphabetic 'Enforcement' character which represents the current year, 
--              for example FWT00342.
--              These derive their next value from rows where SYSTEM_DATA.ITEM = "FOREIGN", for the court WARRANTS.CURRENTLY_OWNED_BY.
--              Stored in the column WARRANTS.LOCAL_WARRANT_NUMBER.
--
--              Re-issue Warrants (Warrant Numbers) :-
--                  This is 5 digit sequential number, padded with zeros, which has the last 2 digits of 
--              the year appended to it, after a '/' character, for example 00342/06.
--              These derive their next value from rows where SYSTEM_DATA.ITEM = "REISSUE", for the court WARRANTS.ISSUED_BY.
--              Stored in the column WARRANTS.WARRANT_NUMBER.
--
-- Changes
-- 05/04/2006 CJH: Foreign warrants based on CURRENTLY_OWNED_BY , not issued_by_court_code
-- 08/05/2006 PEH: Refine the criteria for identifying REISSUE warrant numbers in set_reissue_warrant_nextval().
--            (TD 3284: UC031 - Re-issue Warrant - Error on clicking 'Save' button. Unique Constraint Violated)
-- 13/07/2006 PEH: Modified select statements to get the max of a substring of the Warrant Number 
--            other formatting characters - as this caused problem where the database had been populated
--            with values for other years.
-- 21/08/2006 PEH: Modified c_get_nextval in set_home_warrant_nextval, by adding the extra condition 
--            "AND W.LOCAL_WARRANT_NUMBER IS NULL".  Foreign Warrant can be entered that have Warrant Numbers
--            that actual belong to other courts, therefore we need to exclude from the selection.
declare

    procedure create_system_data_sequence(
        p_item_name in SYSTEM_DATA.ITEM%type, 
        p_item_value in SYSTEM_DATA.ITEM_VALUE%type) as

    	cursor c_courts(
    	    p_item_name SYSTEM_DATA.ITEM%type)
    	is
        	SELECT	CT.CODE
        	FROM	COURTS CT
        	WHERE	CT.CODE not in 
        	(SELECT	SD.ADMIN_COURT_CODE
    		 FROM	SYSTEM_DATA SD
    		 WHERE	SD.ITEM = p_item_name
            );
      
      court_code courts.code%type;
      
    begin
        open c_courts(p_item_name);
        loop
            fetch c_courts into court_code;
        	if c_courts%notfound then
        		close c_courts;
        		exit;
        	else
        		INSERT INTO	SYSTEM_DATA
        		( ITEM
        		, ITEM_VALUE
        		, ITEM_VALUE_CURRENCY
        		, ADMIN_COURT_CODE
        		) VALUES 
        		( p_item_name
        		, p_item_value
        		, NULL
        		, court_code
        		);
        	end if;
        end loop;        
    end create_system_data_sequence;
    
    procedure set_home_warrant_nextval as

        -- Get the Maximum WARRANT_NUMBER for each Court.
        -- Ignore rows that contain badly formatted Warrant Numbers.
        cursor c_get_nextval is
            SELECT W.ISSUED_BY
            ,      MAX(SUBSTR(W.WARRANT_NUMBER, 2))
            FROM   WARRANTS W
            WHERE  W.WARRANT_NUMBER IS NOT NULL
            AND    W.LOCAL_WARRANT_NUMBER IS NULL
            AND    LENGTH(W.WARRANT_NUMBER) = 8
            AND    SUBSTR(W.WARRANT_NUMBER, 1, 1) NOT IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 2, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 3, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 4, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 5, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 6, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 7, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 8, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            GROUP BY W.ISSUED_BY;

    	issued_by_court_code WARRANTS.ISSUED_BY%type;
    	max_warrant_number   WARRANTS.WARRANT_NUMBER%type;
    	txt_sequence_number  SYSTEM_DATA.ITEM_VALUE%type;
    	sequence_number      SYSTEM_DATA.ITEM_VALUE%type;

    begin
        open c_get_nextval;
        loop
            fetch c_get_nextval into 
                issued_by_court_code,
                max_warrant_number;
        	if c_get_nextval%notfound then
        		close c_get_nextval;
        		exit;
        	else
				txt_sequence_number := max_warrant_number;

				-- Convert to a number.
				sequence_number := TO_NUMBER(txt_sequence_number);

				-- Set to the next available number.
				sequence_number := sequence_number + 1;
        		
        		UPDATE SYSTEM_DATA  SD
        		SET    ITEM_VALUE   = sequence_number
        		WHERE  SD.ITEM      = 'HOME'
        		AND    SD.ADMIN_COURT_CODE = issued_by_court_code;
        	end if;
        end loop;        
    end set_home_warrant_nextval;

    procedure set_foreign_warrant_nextval as

        -- Get the Maximum WARRANT_NUMBER for each Court.
        -- Ignore rows that contain badly formatted Warrant Numbers.
        cursor c_get_nextval is
            SELECT W.CURRENTLY_OWNED_BY
            ,      MAX(SUBSTR(W.LOCAL_WARRANT_NUMBER, 4))
            FROM   WARRANTS W
            WHERE  W.LOCAL_WARRANT_NUMBER IS NOT NULL
            AND    LENGTH(W.LOCAL_WARRANT_NUMBER) = 8
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 1, 2) = 'FW'
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 3, 1) NOT IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 4, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 5, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 6, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 7, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.LOCAL_WARRANT_NUMBER, 8, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            GROUP BY W.CURRENTLY_OWNED_BY;

    	currently_owned_by_court_code 	WARRANTS.CURRENTLY_OWNED_BY%type;
    	max_warrant_number   		WARRANTS.WARRANT_NUMBER%type;
    	txt_sequence_number  		SYSTEM_DATA.ITEM_VALUE%type;
    	sequence_number      		SYSTEM_DATA.ITEM_VALUE%type;

    begin
        open c_get_nextval;
        loop
            fetch c_get_nextval into 
                currently_owned_by_court_code,
                max_warrant_number;
        	if c_get_nextval%notfound then
        		close c_get_nextval;
        		exit;
        	else
				txt_sequence_number := max_warrant_number;

				-- Convert to a number.
				sequence_number := TO_NUMBER(txt_sequence_number);

				-- Set to the next available number.
				sequence_number := sequence_number + 1;
        		
        		UPDATE SYSTEM_DATA  SD
        		SET    ITEM_VALUE   = sequence_number
        		WHERE  SD.ITEM      = 'FOREIGN'
        		AND    SD.ADMIN_COURT_CODE = currently_owned_by_court_code;
        	end if;
        end loop;        
    end set_foreign_warrant_nextval;
    
    procedure set_reissue_warrant_nextval as

        -- Get the Maximum WARRANT_NUMBER for each Court.
        -- Ignore rows that contain badly formatted Warrant Numbers.
        cursor c_get_nextval is
            SELECT W.ISSUED_BY
            ,      MAX(SUBSTR(W.WARRANT_NUMBER, 1, 5))
            FROM   WARRANTS W
            WHERE  W.WARRANT_NUMBER IS NOT NULL
            AND    LENGTH(W.WARRANT_NUMBER) = 8
            AND    SUBSTR(W.WARRANT_NUMBER, 1, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 2, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 3, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 4, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 5, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 6, 1) = '/'
            AND    SUBSTR(W.WARRANT_NUMBER, 7, 1) IN ('0','1','2','3','4','5','6','7','8','9')
            AND    SUBSTR(W.WARRANT_NUMBER, 8, 1) IN ('0','1','2','3','4','5','6','7','8','9')            
            GROUP BY W.ISSUED_BY;

    	issued_by_court_code WARRANTS.ISSUED_BY%type;
    	max_warrant_number   WARRANTS.WARRANT_NUMBER%type;
    	txt_sequence_number  SYSTEM_DATA.ITEM_VALUE%type;
    	sequence_number      SYSTEM_DATA.ITEM_VALUE%type;

    begin
        open c_get_nextval;
        loop
            fetch c_get_nextval into 
                issued_by_court_code,
                max_warrant_number;
        	if c_get_nextval%notfound then
        		close c_get_nextval;
        		exit;
        	else
				txt_sequence_number := max_warrant_number;

				-- Convert to a number.
				sequence_number := TO_NUMBER(txt_sequence_number);

				-- Set to the next available number.
				sequence_number := sequence_number + 1;
        		
        		UPDATE SYSTEM_DATA  SD
        		SET    ITEM_VALUE   = sequence_number
        		WHERE  SD.ITEM      = 'REISSUE'
        		AND    SD.ADMIN_COURT_CODE = issued_by_court_code;
        	end if;
        end loop;        
    end set_reissue_warrant_nextval;
    
begin
    create_system_data_sequence('HOME',   1);
    create_system_data_sequence('FOREIGN',1);
    create_system_data_sequence('REISSUE',1);
    
    set_home_warrant_nextval;
    set_foreign_warrant_nextval;
    set_reissue_warrant_nextval;
    
    commit;
end;
/
