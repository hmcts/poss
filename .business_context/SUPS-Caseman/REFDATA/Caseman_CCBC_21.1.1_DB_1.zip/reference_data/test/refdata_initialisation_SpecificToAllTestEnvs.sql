-- Project:     SUPS Caseman
-- File:        refdata_initialisation_SpecificToAllTestEnvs.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: TO BE RUN ONLY 
--      	      1) In environments which DO NOT have migrated data
-- 		      2) on first load and subsequent recovery situations
-- 
-- DO NOT RUN THIS SCRIPT!! IT WILL BE CALLED BY ENVIRONMENT SPECIFIC SCRIPTS
--
-- Change History:
-- 


set define off

exec set_sups_app_ctx('a','b','c');

-- THIS BLOCK RELATES TO THE SYSTEM_DATA
@init_system_data_seqs.sql
@init_system_data_non_seqs.sql
@init_ae_seq.sql
@init_co_seq.sql
@init_warrants_seq.sql
@create_cfo_item.sql

--MISC DATA CORRECTIONS RELATING TO OLD DEFECTS
@co_event_200_hrg_seq.sql
@p2p_role_ncp_to_solicitor.sql

