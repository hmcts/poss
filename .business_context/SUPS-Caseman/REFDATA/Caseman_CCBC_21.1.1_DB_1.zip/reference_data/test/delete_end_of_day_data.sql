-- Original author: Chris Vincent

-- Comment from Chris Hutt 29/8/06 as part of defect 4746 investigation
-- This script was initially created to support the rollout of Suitors Cash.
-- It's continued usage is dangerouus - DO NOT RUN  

DELETE FROM PAYMENT_SUMMARY;

INSERT INTO PAYMENT_SUMMARY
(
REPORT_ID,
DCS_DATE,
INOUT,
ADMIN_COURT_CODE,
VALID,
ORDINARY_CURRENCY,
ORDINARY,
JGMT1000_CURRENCY,
JGMT1000,
CHEQUE_CURRENCY,
CHEQUE,
AO_CAEO_CURRENCY,
AO_CAEO,
INSATIS_CURRENCY,
INSATIS,
PTO_ORDER_CURRENCY,
PTO_ORDER,
MISCELLANEOUS_CURRENCY,
MISCELLANEOUS,
TRANSACTION_TOTAL)
VALUES (
'B/F99999',
TO_DATE('2006-01-23', 'YYYY-MM-DD'),
'I',
282,
'Y',
'GBP',
10,
'GBP',
20,
'GBP',
30,
'GBP',
40,
'GBP',
50,
'GBP',
60,
'GBP',
70,
100
);