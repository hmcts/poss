-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsCAT.sql
-- Author:      Chris Hutt
-- Created:     9 oct 2007 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the CAT environment
--		
-- NOTE: printer allocation currently hed in cat_dca_user.csv and court.csv
--
-- Change History:
--              Chris Hutt 6 Nov 07
--              No longer calls refdata_refresh_SpecificToAllTestEnvs.sql. specific driver was need for a 
--              dedicated set of cat users, but this approach lends itself to future tailoring and Im
--              told CAT is a bit of a one off.


set define off


exec set_sups_app_ctx('a','b','c');

update courts set id = null;

@courts.sql
@create_court_sections.sql
@given_addresses.sql
@parties.sql
@cat_sections.sql
@cat_dca_user.sql
@cat_user_role.sql
@cat_user_court.sql
@init_personalise.sql
@personalise.sql


commit;