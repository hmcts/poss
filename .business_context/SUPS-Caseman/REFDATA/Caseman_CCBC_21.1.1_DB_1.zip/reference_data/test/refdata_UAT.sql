-- Project:     SUPS Caseman
-- File:        refdata_UAT.sql
-- Author:      Chris Hutt
-- Created:     30 NOV 2006 
-- Description: A fix ref data refresh for the UAT environment
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_EnvSpecificsUAT.sql

commit;