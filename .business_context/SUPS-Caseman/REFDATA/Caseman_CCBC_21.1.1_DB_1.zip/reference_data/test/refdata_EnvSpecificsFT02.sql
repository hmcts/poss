-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsFT02.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the FT02 environment
--		
-- NOTE: printer allocation currently done in tamworth_courts.sql
--
-- Change History:
-- 

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql
@tamworth_courts.sql

update courts set sups_centralised_flag = 'N'
where code in (998);

