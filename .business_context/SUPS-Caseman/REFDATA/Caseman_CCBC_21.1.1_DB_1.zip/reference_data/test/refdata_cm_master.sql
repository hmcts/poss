-- Project:     SUPS Caseman
-- File:        refdata_cman_master.sql
-- Author:      Chris Hutt
-- Created:     31may07 
-- Description: A fix ref data refresh for the CM_MASTER environment
--
-- Change History:
-- 


-- DO NOTHING NO REF DATA IN THIS ENVIRONMENT !!
