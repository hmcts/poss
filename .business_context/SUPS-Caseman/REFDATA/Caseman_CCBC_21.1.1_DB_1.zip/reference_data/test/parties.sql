drop table parties_ext;

create table parties_ext (
PARTY_ID                                           NUMBER(12),
PERSON_TITLE                                       VARCHAR2(35),
PERSON_GIVEN_FIRST_NAME                            VARCHAR2(35),
PERSON_GIVEN_SECOND_NAME                           VARCHAR2(35),
PERSON_FAMILY_NAME                                 VARCHAR2(35),
PERSON_GIVEN_THIRD_NAME                            VARCHAR2(35),
AUTHENTICATION_PIN                                 NUMBER(4),
COMPANY_NAME                                       VARCHAR2(80),
AUTHENTICATION_PASSWORD                            VARCHAR2(12),
EMAIL_ADDRESS                                      VARCHAR2(254),
GENDER                                             NUMBER(1),
ETHNIC_ORIGIN_CODE                                 VARCHAR2(10),
PARTY_TYPE_CODE                                    VARCHAR2(10),
FAX_NUMBER                                         VARCHAR2(24),
PERSON_REQUESTED_NAME                              VARCHAR2(70),
TEL_NO                                             VARCHAR2(24),
DX_NUMBER                                          VARCHAR2(40))
organization external
(
  default directory caseman_rd_dir
  access parameters
  (
    records delimited by newline
    fields terminated by ','
    missing field values are null
    (
PARTY_ID                       ,
PERSON_TITLE                   ,
PERSON_GIVEN_FIRST_NAME        ,
PERSON_GIVEN_SECOND_NAME       ,
PERSON_FAMILY_NAME             ,      
PERSON_GIVEN_THIRD_NAME        ,
AUTHENTICATION_PIN             ,
COMPANY_NAME                   ,
AUTHENTICATION_PASSWORD        ,
EMAIL_ADDRESS                  ,
GENDER                         ,
ETHNIC_ORIGIN_CODE             ,
PARTY_TYPE_CODE                ,
FAX_NUMBER                     ,
PERSON_REQUESTED_NAME          ,
TEL_NO                         ,
DX_NUMBER                      ,
PARTY_ROLE_DESCRIPTION
    ))
  location ('parties.csv')
);

merge into parties REF
using 
(select 
PARTY_ID                       ,
PERSON_TITLE                   ,
PERSON_GIVEN_FIRST_NAME        ,
PERSON_GIVEN_SECOND_NAME       ,
PERSON_FAMILY_NAME             ,
PERSON_GIVEN_THIRD_NAME        ,
AUTHENTICATION_PIN             ,
COMPANY_NAME                   ,
AUTHENTICATION_PASSWORD        ,
EMAIL_ADDRESS                  ,
GENDER                         ,
ETHNIC_ORIGIN_CODE             ,
PARTY_TYPE_CODE                ,
FAX_NUMBER                     ,
PERSON_REQUESTED_NAME          ,
TEL_NO                         ,
DX_NUMBER                      
from parties_ext) TMP
on (TMP.PARTY_ID = REF.PARTY_ID)
when matched then update set
REF.PERSON_TITLE = TMP.PERSON_TITLE                          ,
REF.PERSON_GIVEN_FIRST_NAME = TMP.PERSON_GIVEN_FIRST_NAME    ,            
REF.PERSON_GIVEN_SECOND_NAME = TMP.PERSON_GIVEN_SECOND_NAME  ,     
REF.PERSON_FAMILY_NAME = TMP.PERSON_FAMILY_NAME              ,           
REF.PERSON_GIVEN_THIRD_NAME = TMP.PERSON_GIVEN_THIRD_NAME    ,           
REF.AUTHENTICATION_PIN = TMP.AUTHENTICATION_PIN              ,           
REF.COMPANY_NAME = TMP.COMPANY_NAME                          ,           
REF.AUTHENTICATION_PASSWORD = TMP.AUTHENTICATION_PASSWORD    ,           
REF.EMAIL_ADDRESS = TMP.EMAIL_ADDRESS                        ,           
REF.GENDER = TMP.GENDER                                      ,           
REF.ETHNIC_ORIGIN_CODE = TMP.ETHNIC_ORIGIN_CODE              ,           
REF.PARTY_TYPE_CODE = TMP.PARTY_TYPE_CODE                    ,           
REF.FAX_NUMBER = TMP.FAX_NUMBER                              ,           
REF.PERSON_REQUESTED_NAME = TMP.PERSON_REQUESTED_NAME        ,           
REF.TEL_NO = TMP.TEL_NO                                      ,           
REF.DX_NUMBER = TMP.DX_NUMBER                       
when not matched then insert (
PARTY_ID                   ,    
PERSON_TITLE               ,    
PERSON_GIVEN_FIRST_NAME    ,    
PERSON_GIVEN_SECOND_NAME   ,    
PERSON_FAMILY_NAME         ,    
PERSON_GIVEN_THIRD_NAME    ,    
AUTHENTICATION_PIN         ,    
COMPANY_NAME               ,    
AUTHENTICATION_PASSWORD    ,    
EMAIL_ADDRESS              ,    
GENDER                     ,    
ETHNIC_ORIGIN_CODE         ,    
PARTY_TYPE_CODE            ,    
FAX_NUMBER                 ,    
PERSON_REQUESTED_NAME      ,    
TEL_NO                     ,    
DX_NUMBER                      )
values (
TMP.PARTY_ID                 ,      
TMP.PERSON_TITLE             ,      
TMP.PERSON_GIVEN_FIRST_NAME  ,      
TMP.PERSON_GIVEN_SECOND_NAME ,      
TMP.PERSON_FAMILY_NAME       ,      
TMP.PERSON_GIVEN_THIRD_NAME  ,      
TMP.AUTHENTICATION_PIN       ,      
TMP.COMPANY_NAME             ,      
TMP.AUTHENTICATION_PASSWORD  ,      
TMP.EMAIL_ADDRESS            ,      
TMP.GENDER                   ,      
TMP.ETHNIC_ORIGIN_CODE       ,      
TMP.PARTY_TYPE_CODE          ,      
TMP.FAX_NUMBER               ,      
TMP.PERSON_REQUESTED_NAME    ,      
TMP.TEL_NO                   ,      
TMP.DX_NUMBER                      );

drop table parties_ext;