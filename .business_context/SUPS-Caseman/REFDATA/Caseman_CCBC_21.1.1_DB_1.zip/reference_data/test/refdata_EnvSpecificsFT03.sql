-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsIT01.sql
-- Author:      Chris Hutt
-- Created:     31may07 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the Ft03 environment
--
-- Change history:
--
-- Chris Hutt 7june07 - dca_user.default_printer updates added for courts 180, 111 and 282.		


set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

update courts 
set default_printer = 'xerox_2', fap_id = 'csf20099';

update dca_user d
set d.user_default_printer = 'xerox_2'
where d.user_id in (select c.user_id 
                   from user_court c
                   where c.user_id = d.user_id 
                   and   c.court_code = 180);


update courts 
set default_printer = 'Egypt' where code = '282';

update dca_user d
set d.user_default_printer = 'Egypt'
where d.user_id in (select c.user_id 
                   from user_court c
                   where c.user_id = d.user_id 
                   and   c.court_code = 282);

update courts 
set default_printer = 'Camberley' where code = '111';

update dca_user d
set d.user_default_printer = 'Camberley'
where d.user_id in (select c.user_id 
                   from user_court c
                   where c.user_id = d.user_id 
                   and   c.court_code = 111);


commit;