
-- UAT_SUPS_courts.sql
-- 1. Specifies SUPS courts for UAT (COV=180, NORTHAMPTON = 282, WOLVES = 378)
-- 
--
-- Chris Hutt 7 nov 2006
--
-- Change history
-- Chris Vincent (11/10/2006) Adding Grouping Court Changes
-- Chris hutt 17oct07 : SUPS_CENTRALISED_FLAG settings removed.
--                      Printer allocation as per Dave Gwynne's spec.


-- PRINTER ALLOCATIONS

update courts 
set default_printer = 'LINKPTR04', fap_id = 'CSF20099';

update dca_user
set user_default_printer = 'LINKPTR04';


--UPDATE COURTS SET SUPS_CENTRALISED_FLAG = 'N' ;

--UPDATE COURTS SET SUPS_CENTRALISED_FLAG = 'Y' WHERE CODE IN (180, 282, 378);


-- GROUPING COURT CHANGES
UPDATE COURTS C SET C.WFT_GROUPING_COURT = 282, C.WFT_DM_EMAIL_ADDRESS = 'dm@northampton.gov.uk'
WHERE C.CODE = 282;

UPDATE COURTS C SET C.WFT_GROUPING_COURT = 180, C.WFT_DM_EMAIL_ADDRESS = 'dm@coventry.gov.uk'
WHERE C.CODE = 180;

UPDATE COURTS C SET C.WFT_GROUPING_COURT = 378, C.WFT_DM_EMAIL_ADDRESS = 'dm@coventry.gov.uk'
WHERE C.CODE = 378;

UPDATE COURTS C SET C.WFT_GROUPING_COURT = 127, C.WFT_DM_EMAIL_ADDRESS = 'dm@coventry.gov.uk'
WHERE C.CODE = 170;

UPDATE COURTS C SET C.WFT_GROUPING_COURT = 282, C.WFT_DM_EMAIL_ADDRESS = 'dm@northampton.gov.uk'
WHERE C.CODE = 262;

COMMIT;