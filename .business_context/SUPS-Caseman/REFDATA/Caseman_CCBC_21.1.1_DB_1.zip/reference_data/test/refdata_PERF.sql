-- Project:     SUPS Caseman
-- File:        refdata_PERF.sql
-- Author:      Chris Hutt
-- Created:     30 NOV 2006 
-- Description: A fix ref data refresh for the Performance environment
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_EnvSpecificsPERF.sql

commit;