update courts set fap_id = 'csb00001';
commit;