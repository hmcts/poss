-- Project:     SUPS Caseman
-- File:        refdata_CAT.sql
-- Author:      Chris Hutt
-- Created:     9 oct 2007 
-- Description: A fix ref data refresh for the CAT environment
--              (CCBC CustomerAcceptanceTest)
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_EnvSpecificsCAT.sql

commit;