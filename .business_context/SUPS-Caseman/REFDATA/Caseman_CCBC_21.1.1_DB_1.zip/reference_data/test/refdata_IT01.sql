-- Project:     SUPS Caseman
-- File:        refdata_DEVINT.sql
-- Author:      Chris Hutt
-- Created:     30 NOV 2006 
-- Description: A fix ref data refresh for the IT01 environment
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_EnvSpecificsIT01.sql

commit;