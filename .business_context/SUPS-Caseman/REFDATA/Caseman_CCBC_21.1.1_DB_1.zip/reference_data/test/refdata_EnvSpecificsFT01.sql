-- Project:     SUPS Caseman
-- File:        refdata_EnvSpecificsFT01.sql
-- Author:      Chris Hutt
-- Created:     29 NOV 2006 
-- Description: Run scripts loading reference data which is classified as being specific to
--              the FT01 environment
--		
-- NOTE: printer allocation currently done in tamworth_courts.sql
--
-- Change History:
-- Chris Hutt 4july07 - defect 6339 dca_user.default_printer updates added for courts 180, 111 and 282.		
-- 

set define off

@refdata_refresh_SpecificToAllTestEnvs.sql

@tamworth_courts.sql

update courts set sups_centralised_flag = 'N'
where code in (998);


update courts 
set default_printer = 'xerox_2', fap_id = 'csf20099';

update dca_user d
set d.user_default_printer = 'xerox_2'
where d.user_id in (select c.user_id 
                   from user_court c
                   where c.user_id = d.user_id 
                   and   c.court_code = 180);


update courts 
set default_printer = 'Egypt' where code = '282';

update dca_user d
set d.user_default_printer = 'Egypt'
where d.user_id in (select c.user_id 
                   from user_court c
                   where c.user_id = d.user_id 
                   and   c.court_code = 282);

update courts 
set default_printer = 'Camberley' where code = '111';

update dca_user d
set d.user_default_printer = 'Camberley'
where d.user_id in (select c.user_id 
                   from user_court c
                   where c.user_id = d.user_id 
                   and   c.court_code = 111);


commit;


