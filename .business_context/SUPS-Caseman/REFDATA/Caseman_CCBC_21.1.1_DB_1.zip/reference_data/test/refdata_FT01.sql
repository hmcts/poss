-- Project:     SUPS Caseman
-- File:        refdata_FT01.sql
-- Author:      Chris Hutt
-- Created:     30 NOV 2006 
-- Description: A fix ref data refresh for the FT01 environment
--
-- Change History:
-- 

@refdata_refresh_BuildSpecificEnvNeutral.sql
@refdata_EnvSpecificsFT01.sql

commit;