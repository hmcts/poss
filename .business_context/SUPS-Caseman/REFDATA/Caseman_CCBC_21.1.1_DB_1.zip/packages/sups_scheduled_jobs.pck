/*************************************************************************
 Module:            sups_scheduled_jobs
 
 Description:       Contains jobs to be executed by the scheduler in the SUPS Environment.

 Amendment History

 Version   Date         Name             Amendment
 ------------------------------------------------------------------------  
1.1       12/12/06      P.Haferer	  Created using code provided by Hilary Bannister/Alistair Brown.
1.2       25/06/07      C J Hutt       Added in the CCBC scheduled job 'cc_clear_document_store'
1.3       06/09/07	    P. Scanlon     Modified cc_clear_document_store to 
                                       also clear orphaned wp_outputs. ICR0395
1.4       25/10/07      P Scanlon      Defect 1126. Modified  delete of document_store to remove
                                       records only if no corresponding wp_output. 
1.5       15/04/07      C Vincent      Modified delete from REPORT_QUEUE to wrap XMLSOURCE
									   with the xmlsource_numcheck function for performance.
*******************************************************************************/

create or replace package sups_scheduled_jobs is

    PROCEDURE cm_set_new_server_secret (new_expiry_date  IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE+1,'YYYY-MM-DD HH24:MI:SS'));
    
    PROCEDURE cc_clear_document_store;



end sups_scheduled_jobs;
/

create or replace package body sups_scheduled_jobs is

   set_raise_application_error BOOLEAN;

   procedure cm_set_new_server_secret (new_expiry_date  IN VARCHAR2 DEFAULT TO_CHAR(SYSDATE+1,'YYYY-MM-DD HH24:MI:SS'))
   as
      l_found_server_secret   NUMBER := 0;
      l_new_expiry_date       DATE;
      l_new_secret_main       VARCHAR2(4000);
      function f_new_secret return varchar2
      is
         l_current_length        NUMBER := 0;
         l_new_length            NUMBER := 128;
         l_new_secret            VARCHAR2(4000);
      begin
         for r_new_length in (select round(dbms_random.value(128,512),0) new_length from dual)
         loop
            l_new_length := r_new_length.new_length;
         end loop;
         l_new_secret := '{' ;
         while l_current_length < l_new_length
         loop
            l_current_length := l_current_length + 1;
            for r_next_hex in (select lpad(trim(to_char(round(dbms_random.value(0,255),0),'xx')),2,'0') next_hex from dual)
            loop
               if l_current_length = l_new_length
               then
                  l_new_secret := l_new_secret || '0x' || r_next_hex.next_hex || '}' ;
               else
                  l_new_secret := l_new_secret || '0x' || r_next_hex.next_hex || ':' ;
               end if;
            end loop;
         end loop;
         return l_new_secret;
      end f_new_secret;
   begin
      begin
         l_new_expiry_date := to_date(new_expiry_date,'YYYY-MM-DD HH24:MI:SS');
      exception
         when others then
            l_new_expiry_date := sysdate + 1;
      end;
      for r_server_secret in (select SERVER_SECRET_ID, EXPIRY_DATE, SECRET
                              from   server_secret)
      loop
         l_found_server_secret := 1;
         l_new_secret_main := f_new_secret;
         update server_secret set secret = l_new_secret_main,
                                  expiry_date = l_new_expiry_date
         where  server_secret_id = r_server_secret.SERVER_SECRET_ID;
      end loop;
      if l_found_server_secret = 0
      then
         l_new_secret_main := f_new_secret;
         insert into server_secret (SERVER_SECRET_ID, EXPIRY_DATE, SECRET)
         values (1,l_new_expiry_date,l_new_secret_main);
      end if;
      commit;
   end cm_set_new_server_secret;

PROCEDURE cc_clear_document_store AS

   BEGIN

     SET_SUPS_APP_CTX (P_APP_USERID    => 'OVERNIGHT',
                       P_APP_COURTID   => '000',
                       P_APP_PROCESSID => 'SUPS_SCHEDULED_JOBS2');

      -- identify all documents that are not permanently stored (dont have a value -1) and that the storage duration has expired (CREATED_DATE+STORAGE_DURATION) is younger than today's date
      -- delete all the content_store rows that the documents use
      -- delete all the document_store rows
      -- delete all the report queue rows that refer to these documents 
      -- delete all orphaned wp_outputs

     DELETE FROM REPORT_QUEUE RQ
     WHERE  (
               RQ.STORAGE_DURATION != -1
               AND    TRUNC(SYSDATE) > RQ.CREATED_DATE + RQ.STORAGE_DURATION
             )
        OR   ( RQ.TYPE in ('3','4')
               AND RQ.STORAGE_DURATION = -1
               AND NOT EXISTS (SELECT 1 FROM WP_OUTPUT W WHERE xmlsource_numcheck(W.XMLSOURCE) = RQ.DOCUMENT_ID)
             );

      -- delete all "parent-less" document_store rows and content_store rows

     DELETE FROM DOCUMENT_STORE D 
     WHERE NOT EXISTS (SELECT 1 FROM REPORT_QUEUE R WHERE R.DOCUMENT_ID = D.ID)
     AND   NOT EXISTS (SELECT 1 FROM WP_OUTPUT W WHERE W.XMLSOURCE=D.ID AND NVL(W.FINAL_IND,'N') = 'N'   );



     DELETE FROM CONTENT_STORE C WHERE NOT EXISTS (SELECT 1 FROM DOCUMENT_STORE D WHERE D.CONTENT_STORE_ID = C.ID);

     -- if we do not reach here then this is probably because we have blown a rollback segment somewhere
     -- this procedure may need to be broken down into smaller commit blocks.
     commit;

     dbms_output.put_line('Successfully completed cc_clear_document_store.');

   END cc_clear_document_store;


BEGIN
   set_raise_application_error := FALSE;
END sups_scheduled_jobs;

/
